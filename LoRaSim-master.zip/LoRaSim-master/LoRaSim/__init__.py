name = "LoRaSim"


def launch_gui():
    from LoRaSim.gui.main import launch
    launch()


if __name__ == "__main__":
    launch_gui()
